package es.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;

import es.models.Letra;
import es.services.WordleService;

@Controller
@RequestMapping("/")
public class WordleController {
    @Autowired
    WordleService wordleService;
    
    @GetMapping("/wordle")
    public ModelAndView wordle() {
        ModelAndView mav = new ModelAndView("wordle");
        mav.addObject("Intentos", wordleService.getIntentos());
        return mav;
    }
    @GetMapping("/wordle")
    public ModelAndView checWord(String word) {
        List<Letra> list = wordleService.checkPalabra(word);
		List<String> history = wordleService.historial();
        boolean win = false;
        if (list != null) {
            for (Letra letra : list) {
                if(letra.isAcertada() && letra.getPosicion() == letra.getCorrectPosition()){
                    win = true;
                }else{
                    win = false;
                    break;
                }
            }
        }
        ModelAndView modelAndView;
        if (win) {
            modelAndView = new ModelAndView("win");
        }else{
            modelAndView = new ModelAndView("word");
        }
        modelAndView.addObject("word", list);
        modelAndView.addObject("history", history);
        modelAndView.addObject("Attempts", wordleService.getIntentos());
        return modelAndView;
	}

}
