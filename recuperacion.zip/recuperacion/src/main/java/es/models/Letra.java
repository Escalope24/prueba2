package es.models;

public class Letra {
    private char letra;
    private boolean acertada;
    private int posicion;
    private int correctPosition;
    public int getCorrectPosition() {
        return correctPosition;
    }
    public void setCorrectPosition(int correctPosition) {
        this.correctPosition = correctPosition;
    }
    // generar constructor
    public Letra(char letra, int posicion, boolean acertada, int correctPosition) {
        this.letra = letra;
        this.posicion = posicion;
        this.acertada = false;
    }
    // generar getters y setters
    public char getLetra() {
        return letra;
    }
    public void setLetra(char letra) {
        this.letra = letra;
    }
    public boolean isAcertada() {
        return acertada;
    }
    public void setAcertada(boolean acertada) {
        this.acertada = acertada;
    }
    public int getPosicion() {
        return posicion;
    }
    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }
}
