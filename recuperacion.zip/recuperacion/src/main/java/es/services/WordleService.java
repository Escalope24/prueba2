package es.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.models.Letra;
import es.repository.HardRepository;

@Service
public class WordleService {
    @Autowired
    private HardRepository dificultadRepository;
    public List<Letra> letras = new ArrayList<>();


    public List<Letra> checkPalabra(String word) {
        if (word.length() != dificultadRepository.getLetras().size())
            return null;
        for (int i = 0; i < word.length(); i++) {
            for (int j = 0; j < word.length(); j++) {
                if (word.charAt(i) != dificultadRepository.getLetras().get(i).getLetra())
                    return null;
                else if (word.charAt(i) == dificultadRepository.getLetras().get(i).getLetra()) {
                    letras.add(new Letra(word.charAt(i), i, true, i));
                } else if (word.charAt(i) != dificultadRepository.getLetras().get(i).getLetra() && i != j
                        && word.charAt(i) == dificultadRepository.getLetras().get(j).getLetra()) {
                    letras.add(new Letra(word.charAt(i), i, false, -1));
                } else if (i != j && word.charAt(i) == dificultadRepository.getLetras().get(j).getLetra()) {
                    letras.add(new Letra(word.charAt(i), i, false, j));
                }
            }
        }
        dificultadRepository.addHistorial(word);
        dificultadRepository.restarIntentos();
        dificultadRepository.getIntentos();
        return letras;
    }
    public int getIntentos() {
        return dificultadRepository.getIntentos();
    }
    public List<String> historial() {
        return dificultadRepository.historial();
    }
}
