package es.repository;

import java.util.List;

import es.models.Letra;

public interface IDificultadRepository {
    public String getWord();
    public List <Letra> getLetras();
    public int getIntentos();
    public void restarIntentos();
    public List <String> historial();
    
}
