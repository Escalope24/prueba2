package es.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import es.models.Letra;
@Repository
public class HardRepository implements IDificultadRepository {
    int numIntentos=6;
    private List <String> historial=new ArrayList<>();
    @Override
    public String getWord() {
		List<String> listaPalabras=new ArrayList<>();
		listaPalabras.add("abduzcan");
		listaPalabras.add("abejones");
		listaPalabras.add("cabezazo");
        int num=(int) (Math.random()*listaPalabras.size());
		return listaPalabras.get(num);
    }

    @Override
    public List<Letra> getLetras() {
        String palabra=getWord();
        List<Letra> listaLetras=new ArrayList<>();
        for (int i = 0; i < palabra.length(); i++) {
            Letra letra=new Letra(palabra.charAt(i), i,true,i);
            listaLetras.add(letra);
        }
        return listaLetras;
    }

    @Override
    public int getIntentos() {
        return numIntentos;
    }

    @Override
    public void restarIntentos() {
        numIntentos-=1;
    }

    @Override
    public List<String> historial() {
        return this.historial;
    }
    public void addHistorial(String palabra){
        this.historial.add(palabra);
    }
    
}
